# practice3.py

# ========== Step 1: Imports ==========
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, f1_score
import warnings

warnings.filterwarnings('ignore')

# ========== Step 2: Load and Prepare Corpus ==========
def load_corpus(file_path):
    df = pd.read_csv(file_path)
    df['text'] = df['Titulo_Tokens'] + ' ' + df['Abstract_Tokens']
    return df['text'], df['Seccion']


# ========== Step 3: Split Dataset ==========
def split_dataset(X, y, test_size=0.2):
    return train_test_split(X, y, test_size=test_size, shuffle=True, random_state=0)

# ========== Step 4: Create Text Representations ==========
def create_representations(X_train, X_test):
    representations = {}

    # Binary representation
    binary_vectorizer = CountVectorizer(binary=True)
    X_train_binary = binary_vectorizer.fit_transform(X_train)
    X_test_binary = binary_vectorizer.transform(X_test)
    representations['binary'] = (X_train_binary, X_test_binary)

    # Frequency representation
    freq_vectorizer = CountVectorizer()
    X_train_freq = freq_vectorizer.fit_transform(X_train)
    X_test_freq = freq_vectorizer.transform(X_test)
    representations['frequency'] = (X_train_freq, X_test_freq)

    # TF-IDF representation
    tfidf_vectorizer = TfidfVectorizer()
    X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
    X_test_tfidf = tfidf_vectorizer.transform(X_test)
    representations['tfidf'] = (X_train_tfidf, X_test_tfidf)

    return representations

# ========== Step 5: Define Models ==========
def get_models():
    models = {
        "MultinomialNB": MultinomialNB(),
        "LogisticRegression": LogisticRegression(max_iter=200),
        "SVC": SVC(kernel='linear', C=1),
        "MLPClassifier": MLPClassifier(hidden_layer_sizes=(200,100), max_iter=300)
    }
    return models

# ========== Step 6: Train, Predict and Evaluate ==========
def train_and_evaluate(models, representations, y_train, y_test):
    results = []

    for rep_name, (X_train_rep, X_test_rep) in representations.items():
        for model_name, model in models.items():
            print(f"Training {model_name} with {rep_name} representation...")
            model.fit(X_train_rep, y_train)
            y_pred = model.predict(X_test_rep)

            report = classification_report(y_test, y_pred, zero_division=0)
            f1_macro = f1_score(y_test, y_pred, average='macro', zero_division=0)

            print(f"\nClassification Report for {model_name} with {rep_name}:")
            print(report)

            results.append({
                "Model": model_name,
                "Text Representation": rep_name,
                "F1 Macro": f1_macro
            })

    return pd.DataFrame(results)

# ========== Step 7: Main execution ==========
def main():
    file_path = "arxiv_normalized_corpus.csv"  # CSV file name

    # Load and prepare corpus
    X, y = load_corpus(file_path)

    # Split dataset
    X_train, X_test, y_train, y_test = split_dataset(X, y)

    # Create text representations
    representations = create_representations(X_train, X_test)

    # Define models
    models = get_models()

    # Train and evaluate
    results_df = train_and_evaluate(models, representations, y_train, y_test)

    # Save results
    results_df.to_csv("classification_results.csv", index=False)
    print("\nSummary of Results:")
    print(results_df.sort_values(by="F1 Macro", ascending=False))

if __name__ == "__main__":
    main()
